package com.mahmoud.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "mahmoud_alumital.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                workshop_name TEXT NOT NULL,
                engineer_phone TEXT NOT NULL,
                aluminum_kg_price REAL NOT NULL,
                upvc_meter_price REAL NOT NULL,
                glass_single_sqm_price REAL NOT NULL,
                acc_sliding_kit REAL NOT NULL,
                acc_hinged_kit REAL NOT NULL,
                fly_screen_meter REAL NOT NULL,
                labor_per_sqm REAL NOT NULL,
                waste_percentage REAL NOT NULL,
                kitchen_cladding_sqm REAL NOT NULL,
                kitchen_acc_set REAL NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                customer_name TEXT NOT NULL,
                customer_phone TEXT NOT NULL,
                item_title TEXT NOT NULL,
                details_summary TEXT NOT NULL,
                cutting_details TEXT NOT NULL,
                total_price REAL NOT NULL,
                paid_deposit REAL NOT NULL,
                created_at TEXT NOT NULL
            )
            """.trimIndent()
        )

        db.execSQL(
            """
            CREATE TABLE inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_name TEXT NOT NULL,
                category TEXT NOT NULL,
                quantity REAL NOT NULL,
                unit_name TEXT NOT NULL,
                min_alert_qty REAL NOT NULL
            )
            """.trimIndent()
        )

        // إدخال الإعدادات الافتراضية القابلة للتعديل
        val def = WorkshopSettings()
        val cv = ContentValues().apply {
            put("id", 1)
            put("workshop_name", def.workshopName)
            put("engineer_phone", def.engineerPhone)
            put("aluminum_kg_price", def.aluminumKgPriceEgp)
            put("upvc_meter_price", def.upvcMeterPriceEgp)
            put("glass_single_sqm_price", def.glassSingleSqMPriceEgp)
            put("acc_sliding_kit", def.accessoriesSlidingKitEgp)
            put("acc_hinged_kit", def.accessoriesHingedKitEgp)
            put("fly_screen_meter", def.flyScreenMeterPriceEgp)
            put("labor_per_sqm", def.laborPerSqMEgp)
            put("waste_percentage", def.wastePercentage)
            put("kitchen_cladding_sqm", def.kitchenCladdingSqMPriceEgp)
            put("kitchen_acc_set", def.kitchenAccessorySetEgp)
        }
        db.insert("settings", null, cv)

        // بيانات مخزون ابتدائية تجريبية لتوضيح عمل المخزن
        insertInitialStock(db, "أعواد حلق جرار PS صغير (6 متر)", "قطاعات ألوميتال", 18.0, "عود", 5.0)
        insertInitialStock(db, "أعواد ضلفة جرار PS صغير (6 متر)", "قطاعات ألوميتال", 24.0, "عود", 8.0)
        insertInitialStock(db, "أعواد قطاع مطبخ 2.5×2.5", "قطاعات مطابخ", 15.0, "عود", 6.0)
        insertInitialStock(db, "أطقم عجل جرار تفلون ثقيل", "إكسسوارات", 12.0, "طقم", 5.0)
        insertInitialStock(db, "سقاطات جرار ألومنيوم", "إكسسوارات", 20.0, "قطعة", 6.0)
        insertInitialStock(db, "ألواح فايبر مطابخ", "خامات مطابخ", 4.0, "لوح", 5.0)
    }

    private fun insertInitialStock(
        db: SQLiteDatabase,
        name: String,
        cat: String,
        qty: Double,
        unit: String,
        minQty: Double
    ) {
        val cv = ContentValues().apply {
            put("item_name", name)
            put("category", cat)
            put("quantity", qty)
            put("unit_name", unit)
            put("min_alert_qty", minQty)
        }
        db.insert("inventory", null, cv)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS settings")
        db.execSQL("DROP TABLE IF EXISTS orders")
        db.execSQL("DROP TABLE IF EXISTS inventory")
        onCreate(db)
    }

    fun getSettings(): WorkshopSettings {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM settings WHERE id = 1", null)
        return cursor.use {
            if (it.moveToFirst()) {
                WorkshopSettings(
                    workshopName = it.getString(it.getColumnIndexOrThrow("workshop_name")),
                    engineerPhone = it.getString(it.getColumnIndexOrThrow("engineer_phone")),
                    aluminumKgPriceEgp = it.getDouble(it.getColumnIndexOrThrow("aluminum_kg_price")),
                    upvcMeterPriceEgp = it.getDouble(it.getColumnIndexOrThrow("upvc_meter_price")),
                    glassSingleSqMPriceEgp = it.getDouble(it.getColumnIndexOrThrow("glass_single_sqm_price")),
                    accessoriesSlidingKitEgp = it.getDouble(it.getColumnIndexOrThrow("acc_sliding_kit")),
                    accessoriesHingedKitEgp = it.getDouble(it.getColumnIndexOrThrow("acc_hinged_kit")),
                    flyScreenMeterPriceEgp = it.getDouble(it.getColumnIndexOrThrow("fly_screen_meter")),
                    laborPerSqMEgp = it.getDouble(it.getColumnIndexOrThrow("labor_per_sqm")),
                    wastePercentage = it.getDouble(it.getColumnIndexOrThrow("waste_percentage")),
                    kitchenCladdingSqMPriceEgp = it.getDouble(it.getColumnIndexOrThrow("kitchen_cladding_sqm")),
                    kitchenAccessorySetEgp = it.getDouble(it.getColumnIndexOrThrow("kitchen_acc_set"))
                )
            } else {
                WorkshopSettings()
            }
        }
    }

    fun updateSettings(s: WorkshopSettings) {
        val db = writableDatabase
        val cv = ContentValues().apply {
            put("workshop_name", s.workshopName)
            put("engineer_phone", s.engineerPhone)
            put("aluminum_kg_price", s.aluminumKgPriceEgp)
            put("upvc_meter_price", s.upvcMeterPriceEgp)
            put("glass_single_sqm_price", s.glassSingleSqMPriceEgp)
            put("acc_sliding_kit", s.accessoriesSlidingKitEgp)
            put("acc_hinged_kit", s.accessoriesHingedKitEgp)
            put("fly_screen_meter", s.flyScreenMeterPriceEgp)
            put("labor_per_sqm", s.laborPerSqMEgp)
            put("waste_percentage", s.wastePercentage)
            put("kitchen_cladding_sqm", s.kitchenCladdingSqMPriceEgp)
            put("kitchen_acc_set", s.kitchenAccessorySetEgp)
        }
        db.update("settings", cv, "id = 1", null)
    }

    fun insertOrder(
        customerName: String,
        customerPhone: String,
        itemTitle: String,
        detailsSummary: String,
        cuttingDetailsText: String,
        totalPriceEgp: Double,
        paidDepositEgp: Double
    ): Long {
        val db = writableDatabase
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        val cv = ContentValues().apply {
            put("customer_name", customerName.ifBlank { "عميل نقدي" })
            put("customer_phone", customerPhone)
            put("item_title", itemTitle)
            put("details_summary", detailsSummary)
            put("cutting_details", cuttingDetailsText)
            put("total_price", totalPriceEgp)
            put("paid_deposit", paidDepositEgp)
            put("created_at", now)
        }
        return db.insert("orders", null, cv)
    }

    fun getAllOrders(): List<SavedOrder> {
        val list = mutableListOf<SavedOrder>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM orders ORDER BY id DESC", null)
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    SavedOrder(
                        id = it.getLong(it.getColumnIndexOrThrow("id")),
                        customerName = it.getString(it.getColumnIndexOrThrow("customer_name")),
                        customerPhone = it.getString(it.getColumnIndexOrThrow("customer_phone")),
                        itemTitle = it.getString(it.getColumnIndexOrThrow("item_title")),
                        detailsSummary = it.getString(it.getColumnIndexOrThrow("details_summary")),
                        cuttingDetailsText = it.getString(it.getColumnIndexOrThrow("cutting_details")),
                        totalPriceEgp = it.getDouble(it.getColumnIndexOrThrow("total_price")),
                        paidDepositEgp = it.getDouble(it.getColumnIndexOrThrow("paid_deposit")),
                        createdAt = it.getString(it.getColumnIndexOrThrow("created_at"))
                    )
                )
            }
        }
        return list
    }

    fun deleteOrder(id: Long) {
        writableDatabase.delete("orders", "id = ?", arrayOf(id.toString()))
    }

    fun getAllInventory(): List<InventoryItem> {
        val list = mutableListOf<InventoryItem>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM inventory ORDER BY id DESC", null)
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    InventoryItem(
                        id = it.getLong(it.getColumnIndexOrThrow("id")),
                        itemName = it.getString(it.getColumnIndexOrThrow("item_name")),
                        category = it.getString(it.getColumnIndexOrThrow("category")),
                        quantity = it.getDouble(it.getColumnIndexOrThrow("quantity")),
                        unitName = it.getString(it.getColumnIndexOrThrow("unit_name")),
                        minAlertQty = it.getDouble(it.getColumnIndexOrThrow("min_alert_qty"))
                    )
                )
            }
        }
        return list
    }

    fun addInventoryItem(name: String, cat: String, qty: Double, unit: String, minAlert: Double) {
        val cv = ContentValues().apply {
            put("item_name", name)
            put("category", cat)
            put("quantity", qty)
            put("unit_name", unit)
            put("min_alert_qty", minAlert)
        }
        writableDatabase.insert("inventory", null, cv)
    }

    fun updateInventoryQty(id: Long, newQty: Double) {
        val cv = ContentValues().apply {
            put("quantity", newQty.coerceAtLeast(0.0))
        }
        writableDatabase.update("inventory", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deleteInventoryItem(id: Long) {
        writableDatabase.delete("inventory", "id = ?", arrayOf(id.toString()))
    }
}
