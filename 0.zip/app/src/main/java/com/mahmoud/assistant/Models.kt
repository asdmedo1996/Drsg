package com.mahmoud.assistant

enum class ProfileSystem(
    val titleAr: String,
    val category: String,
    val meterWeightKg: Double,
    val widthDeduction2SashCm: Double,
    val widthDeduction4SashCm: Double,
    val heightDeductionCm: Double,
    val glassDeductionCm: Double,
    val isUpvc: Boolean = false,
    val isHinged: Boolean = false
) {
    PS_SMALL(
        titleAr = "جرار PS صغير",
        category = "ألوميتال جرار",
        meterWeightKg = 0.85,
        widthDeduction2SashCm = -4.5,
        widthDeduction4SashCm = -5.0,
        heightDeductionCm = -6.5,
        glassDeductionCm = -6.5
    ),
    PS_LARGE(
        titleAr = "جرار PS كبير",
        category = "ألوميتال جرار",
        meterWeightKg = 1.15,
        widthDeduction2SashCm = -3.6,
        widthDeduction4SashCm = -4.2,
        heightDeductionCm = -7.5,
        glassDeductionCm = -8.2
    ),
    TANGO(
        titleAr = "جرار تانجو (Tango)",
        category = "ألوميتال جرار",
        meterWeightKg = 1.25,
        widthDeduction2SashCm = -3.2,
        widthDeduction4SashCm = -3.8,
        heightDeductionCm = -8.0,
        glassDeductionCm = -8.5
    ),
    JUMBO(
        titleAr = "جرار جامبو (Jumbo)",
        category = "ألوميتال جرار ثقيل",
        meterWeightKg = 1.55,
        widthDeduction2SashCm = -3.0,
        widthDeduction4SashCm = -3.5,
        heightDeductionCm = -8.5,
        glassDeductionCm = -9.0
    ),
    EL_SAAD(
        titleAr = "جرار السعد (اقتصادي)",
        category = "ألوميتال جرار",
        meterWeightKg = 0.65,
        widthDeduction2SashCm = 1.5,
        widthDeduction4SashCm = 2.0,
        heightDeductionCm = -4.5,
        glassDeductionCm = -5.0
    ),
    CASEMENT_PS(
        titleAr = "مفصلي PS (شباك / باب)",
        category = "ألوميتال مفصلي",
        meterWeightKg = 1.05,
        widthDeduction2SashCm = -6.2,
        widthDeduction4SashCm = -4.8, // used as 1-sash deduction here
        heightDeductionCm = -4.8,
        glassDeductionCm = -7.5,
        isHinged = true
    ),
    UPVC_SLIDING(
        titleAr = "جرار UPVC (مدعم بحديد)",
        category = "PVC",
        meterWeightKg = 1.40,
        widthDeduction2SashCm = -2.4,
        widthDeduction4SashCm = -3.0,
        heightDeductionCm = -7.2,
        glassDeductionCm = -8.0,
        isUpvc = true
    ),
    UPVC_CASEMENT(
        titleAr = "مفصلي UPVC (شباك / باب)",
        category = "PVC",
        meterWeightKg = 1.35,
        widthDeduction2SashCm = -5.6,
        widthDeduction4SashCm = -4.4,
        heightDeductionCm = -4.4,
        glassDeductionCm = -7.8,
        isUpvc = true,
        isHinged = true
    )
}

enum class GlassType(val titleAr: String, val defaultMultiplier: Double) {
    SINGLE_6MM("زجاج سنجل 6 مم شفاف/عاكس", 1.0),
    DOUBLE_18MM("زجاج دبل 18 مم عازل للصوت", 1.85),
    FROSTED_6MM("زجاج مصنفر 6 مم (للحمامات والمطابخ)", 1.1)
}

data class CuttingPiece(
    val partName: String,
    val lengthCm: Double,
    val count: Int,
    val notes: String = ""
)

data class WindowCalcResult(
    val profile: ProfileSystem,
    val widthCm: Double,
    val heightCm: Double,
    val sashCount: Int,
    val hasFlyScreen: Boolean,
    val glassType: GlassType,
    val areaSqM: Double,
    val cuttingList: List<CuttingPiece>,
    val glassWidthCm: Double,
    val glassHeightCm: Double,
    val glassPanelsCount: Int,
    val netGlassAreaSqM: Double,
    val totalLinearMeters: Double,
    val estimatedWeightKg: Double,
    val weightWithWasteKg: Double,
    val materialCostEgp: Double,
    val glassCostEgp: Double,
    val accessoriesCostEgp: Double,
    val laborCostEgp: Double,
    val totalPriceEgp: Double,
    val pricePerSqMEgp: Double
)

enum class KitchenUnitType(val titleAr: String) {
    LOWER_UNIT("وحدة سفلية (تحت الرخامة)"),
    UPPER_UNIT("وحدة علوية (معلقة)"),
    TALL_PANTRY("دولاب خزين / فرن رأسي")
}

enum class KitchenCladdingType(val titleAr: String, val priceMultiplier: Double) {
    FIBER("فايبر جلاس", 1.0),
    CLADDING("كلادينج ألومنيوم (ACP)", 1.45),
    ACRYLIC("أكريليك / بولي لاك", 1.75)
}

data class KitchenCalcResult(
    val unitType: KitchenUnitType,
    val claddingType: KitchenCladdingType,
    val widthCm: Double,
    val heightCm: Double,
    val depthCm: Double,
    val doorsCount: Int,
    val drawersCount: Int,
    val shelvesCount: Int,
    val aluminumMeters: Double,
    val aluminumWeightKg: Double,
    val claddingAreaSqM: Double,
    val cuttingSummary: List<CuttingPiece>,
    val aluminumCostEgp: Double,
    val claddingCostEgp: Double,
    val accessoriesCostEgp: Double,
    val laborCostEgp: Double,
    val totalPriceEgp: Double
)

data class WorkshopSettings(
    val workshopName: String = "مساعد المهندس محمود عبد النبي الطويل",
    val engineerPhone: String = "01000000000",
    val aluminumKgPriceEgp: Double = 245.0,
    val upvcMeterPriceEgp: Double = 190.0,
    val glassSingleSqMPriceEgp: Double = 450.0,
    val accessoriesSlidingKitEgp: Double = 320.0,
    val accessoriesHingedKitEgp: Double = 280.0,
    val flyScreenMeterPriceEgp: Double = 250.0,
    val laborPerSqMEgp: Double = 350.0,
    val wastePercentage: Double = 8.0,
    val kitchenCladdingSqMPriceEgp: Double = 520.0,
    val kitchenAccessorySetEgp: Double = 450.0
)

data class SavedOrder(
    val id: Long = 0,
    val customerName: String,
    val customerPhone: String,
    val itemTitle: String,
    val detailsSummary: String,
    val cuttingDetailsText: String,
    val totalPriceEgp: Double,
    val paidDepositEgp: Double,
    val createdAt: String
)

data class InventoryItem(
    val id: Long = 0,
    val itemName: String,
    val category: String,
    val quantity: Double,
    val unitName: String,
    val minAlertQty: Double
)
