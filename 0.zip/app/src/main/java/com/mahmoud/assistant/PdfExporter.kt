package com.mahmoud.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object PdfExporter {

    fun exportAndShareOrderPdf(
        context: Context,
        settings: WorkshopSettings,
        customerName: String,
        title: String,
        summaryLines: List<String>,
        cuttingList: List<CuttingPiece>,
        totalPriceEgp: Double
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val headerPaint = Paint().apply {
                color = Color.rgb(13, 71, 161)
                textSize = 18f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val subHeaderPaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 13f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val bodyPaint = Paint().apply {
                color = Color.BLACK
                textSize = 12f
                textAlign = Paint.Align.RIGHT
            }
            val linePaint = Paint().apply {
                color = Color.LTGRAY
                strokeWidth = 1.5f
            }

            var y = 45f
            val rightMargin = 555f

            // ترويسة الورشة
            canvas.drawText(settings.workshopName, rightMargin, y, headerPaint)
            y += 22f
            canvas.drawText("هاتف التواصل: ${settings.engineerPhone}", rightMargin, y, subHeaderPaint)
            y += 15f
            canvas.drawLine(40f, y, rightMargin, y, linePaint)

            // بيانات المقايسة
            y += 28f
            canvas.drawText("عرض سعر وأمر تصنيع: $title", rightMargin, y, headerPaint)
            y += 22f
            canvas.drawText("العميل: ${customerName.ifBlank { "عميل نقدي" }}", rightMargin, y, subHeaderPaint)

            y += 24f
            for (line in summaryLines) {
                canvas.drawText(line, rightMargin, y, bodyPaint)
                y += 18f
            }

            y += 10f
            canvas.drawLine(40f, y, rightMargin, y, linePaint)
            y += 24f
            canvas.drawText("جدول قوائم القص والتفصيل (أمر شغل الورشة):", rightMargin, y, subHeaderPaint)
            y += 22f

            for (piece in cuttingList) {
                if (y > 760f) break
                val rowText = "• ${piece.partName} | الطول: ${piece.lengthCm} سم | العدد: ${piece.count} (${piece.notes})"
                canvas.drawText(rowText, rightMargin, y, bodyPaint)
                y += 18f
            }

            y += 14f
            canvas.drawLine(40f, y, rightMargin, y, linePaint)
            y += 28f
            canvas.drawText(
                "الإجمالي النهائي المطلوب: $totalPriceEgp جنيه مصري",
                rightMargin,
                y,
                headerPaint
            )

            pdfDocument.finishPage(page)

            val pdfDir = File(context.cacheDir, "pdfs")
            if (!pdfDir.exists()) pdfDir.mkdirs()
            val pdfFile = File(pdfDir, "عرض_سعر_وأمر_تصنيع_${System.currentTimeMillis()}.pdf")

            FileOutputStream(pdfFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "عرض سعر وأمر تصنيع - ${settings.workshopName}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة أو طباعة ملف PDF"))

        } catch (e: Exception) {
            Toast.makeText(
                context,
                "تعذر تصدير PDF: ${e.localizedMessage}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
