package com.mahmoud.assistant

import kotlin.math.max
import kotlin.math.roundToInt

object AlumitalCalculator {

    fun calculateWindow(
        profile: ProfileSystem,
        widthCm: Double,
        heightCm: Double,
        sashCount: Int,
        hasFlyScreen: Boolean,
        glassType: GlassType,
        settings: WorkshopSettings
    ): WindowCalcResult {
        val safeW = max(widthCm, 30.0)
        val safeH = max(heightCm, 30.0)
        val areaSqM = max((safeW / 100.0) * (safeH / 100.0), 1.0) // الحد الأدنى للتسعير التجاري 1 م2

        val cuttingList = mutableListOf<CuttingPiece>()

        // 1. الحلق الخارجي (Outer Frame)
        cuttingList.add(
            CuttingPiece(
                partName = "حلق عرض (علوي وسفلي)",
                lengthCm = round1(safeW),
                count = 2,
                notes = "قطع زاوية 45 درجة"
            )
        )
        cuttingList.add(
            CuttingPiece(
                partName = "حلق ارتفاع (قوائم جنب)",
                lengthCm = round1(safeH),
                count = 2,
                notes = "قطع زاوية 45 درجة"
            )
        )

        // 2. حساب الضلف (Sashes)
        val effectiveSashes = if (profile.isHinged) {
            if (sashCount <= 1) 1 else 2
        } else {
            if (sashCount >= 4) 4 else if (sashCount == 3) 3 else 2
        }

        val sashWidthCm: Double
        val sashHeightCm = round1(safeH + profile.heightDeductionCm)

        if (profile.isHinged) {
            sashWidthCm = if (effectiveSashes == 1) {
                round1(safeW + profile.widthDeduction4SashCm)
            } else {
                round1((safeW + profile.widthDeduction2SashCm) / 2.0)
            }
            cuttingList.add(
                CuttingPiece(
                    partName = "ضلفة مفصلي عرض (أفقي)",
                    lengthCm = sashWidthCm,
                    count = effectiveSashes * 2,
                    notes = "خصم ${profile.widthDeduction2SashCm} سم"
                )
            )
            cuttingList.add(
                CuttingPiece(
                    partName = "ضلفة مفصلي ارتفاع (رأسي)",
                    lengthCm = sashHeightCm,
                    count = effectiveSashes * 2,
                    notes = "خصم ${profile.heightDeductionCm} سم"
                )
            )
            if (effectiveSashes == 2) {
                cuttingList.add(
                    CuttingPiece(
                        partName = "مرد شباك مفصلي (وسط)",
                        lengthCm = sashHeightCm,
                        count = 1,
                        notes = "يركب على الضلفة الثابتة/التابعة"
                    )
                )
            }
        } else {
            val totalDed = if (effectiveSashes == 4) profile.widthDeduction4SashCm else profile.widthDeduction2SashCm
            sashWidthCm = round1((safeW + totalDed) / effectiveSashes.toDouble())

            cuttingList.add(
                CuttingPiece(
                    partName = "ضلفة جرار عرض (سكلو علوي وسفلي)",
                    lengthCm = sashWidthCm,
                    count = effectiveSashes * 2,
                    notes = "إجمالي فرق العرض ${totalDed} سم ÷ $effectiveSashes"
                )
            )
            cuttingList.add(
                CuttingPiece(
                    partName = "ضلفة جرار ارتفاع (قوائم عدلة ومناصف)",
                    lengthCm = sashHeightCm,
                    count = effectiveSashes * 2,
                    notes = "خصم الارتفاع ${profile.heightDeductionCm} سم"
                )
            )
        }

        // 3. في حالة UPVC: إضافة حديد التسليح الداخلي (الجلفنة)
        if (profile.isUpvc) {
            cuttingList.add(
                CuttingPiece(
                    partName = "حديد تسليح جلفنة للحلق (عرض)",
                    lengthCm = round1(safeW - 8.0),
                    count = 2,
                    notes = "يخصم 8 سم عن الحلق الخارجي للحام"
                )
            )
            cuttingList.add(
                CuttingPiece(
                    partName = "حديد تسليح جلفنة للحلق (ارتفاع)",
                    lengthCm = round1(safeH - 8.0),
                    count = 2,
                    notes = "يخصم 8 سم عن الحلق الخارجي للحام"
                )
            )
        }

        // 4. ضلفة السلك الناموسية (إن وجدت)
        if (hasFlyScreen) {
            val screenCount = if (effectiveSashes == 4) 2 else 1
            val screenW = round1(sashWidthCm + 0.5)
            val screenH = round1(sashHeightCm + 0.3)
            cuttingList.add(
                CuttingPiece(
                    partName = "ضلفة سلك عرض",
                    lengthCm = screenW,
                    count = screenCount * 2,
                    notes = "قطاع سلك ناموسية"
                )
            )
            cuttingList.add(
                CuttingPiece(
                    partName = "ضلفة سلك ارتفاع",
                    lengthCm = screenH,
                    count = screenCount * 2,
                    notes = "قطاع سلك ناموسية"
                )
            )
        }

        // 5. باكتات الزجاج (للمفصلي أو UPVC)
        val glassWidthCm = max(round1(sashWidthCm + profile.glassDeductionCm), 10.0)
        val glassHeightCm = max(round1(sashHeightCm + profile.glassDeductionCm), 10.0)

        if (profile.isHinged || profile.isUpvc) {
            cuttingList.add(
                CuttingPiece(
                    partName = "باكتة زجاج (عرض)",
                    lengthCm = glassWidthCm,
                    count = effectiveSashes * 2,
                    notes = "تثبيت الزجاج"
                )
            )
            cuttingList.add(
                CuttingPiece(
                    partName = "باكتة زجاج (ارتفاع)",
                    lengthCm = glassHeightCm,
                    count = effectiveSashes * 2,
                    notes = "تثبيت الزجاج"
                )
            )
        }

        val netGlassAreaSqM = round2((glassWidthCm / 100.0) * (glassHeightCm / 100.0) * effectiveSashes)

        // إجمالي الأمتار الطولية للقطاعات الأساسية
        var totalCm = 0.0
        for (piece in cuttingList) {
            if (!piece.partName.contains("حديد تسليح")) {
                totalCm += (piece.lengthCm * piece.count)
            }
        }
        val totalLinearMeters = round2(totalCm / 100.0)
        val estimatedWeightKg = round2(totalLinearMeters * profile.meterWeightKg)
        val weightWithWasteKg = round2(estimatedWeightKg * (1.0 + settings.wastePercentage / 100.0))

        // التكلفة بالجنيه المصري
        val materialCostEgp = if (profile.isUpvc) {
            round1(totalLinearMeters * (1.0 + settings.wastePercentage / 100.0) * settings.upvcMeterPriceEgp)
        } else {
            round1(weightWithWasteKg * settings.aluminumKgPriceEgp)
        }

        val glassCostEgp = round1(netGlassAreaSqM * settings.glassSingleSqMPriceEgp * glassType.defaultMultiplier)

        val baseAcc = if (profile.isHinged) settings.accessoriesHingedKitEgp else settings.accessoriesSlidingKitEgp
        val screenCost = if (hasFlyScreen) (areaSqM * settings.flyScreenMeterPriceEgp * 0.5) else 0.0
        val accessoriesCostEgp = round1((baseAcc * (effectiveSashes / 2.0).coerceAtLeast(1.0)) + screenCost)

        val laborCostEgp = round1(areaSqM * settings.laborPerSqMEgp)
        val totalPriceEgp = round1(materialCostEgp + glassCostEgp + accessoriesCostEgp + laborCostEgp)
        val pricePerSqMEgp = round1(totalPriceEgp / areaSqM)

        return WindowCalcResult(
            profile = profile,
            widthCm = safeW,
            heightCm = safeH,
            sashCount = effectiveSashes,
            hasFlyScreen = hasFlyScreen,
            glassType = glassType,
            areaSqM = round2(areaSqM),
            cuttingList = cuttingList,
            glassWidthCm = glassWidthCm,
            glassHeightCm = glassHeightCm,
            glassPanelsCount = effectiveSashes,
            netGlassAreaSqM = netGlassAreaSqM,
            totalLinearMeters = totalLinearMeters,
            estimatedWeightKg = estimatedWeightKg,
            weightWithWasteKg = weightWithWasteKg,
            materialCostEgp = materialCostEgp,
            glassCostEgp = glassCostEgp,
            accessoriesCostEgp = accessoriesCostEgp,
            laborCostEgp = laborCostEgp,
            totalPriceEgp = totalPriceEgp,
            pricePerSqMEgp = pricePerSqMEgp
        )
    }

    fun calculateKitchenUnit(
        unitType: KitchenUnitType,
        claddingType: KitchenCladdingType,
        widthCm: Double,
        heightCm: Double,
        depthCm: Double,
        doorsCount: Int,
        drawersCount: Int,
        shelvesCount: Int,
        settings: WorkshopSettings
    ): KitchenCalcResult {
        val w = max(widthCm, 30.0)
        val h = max(heightCm, 30.0)
        val d = max(depthCm, 25.0)

        val cuttingSummary = mutableListOf<CuttingPiece>()
        // قوائم الكونستركشن (الشاسيه)
        cuttingSummary.add(CuttingPiece("قوائم شاسيه عرض أمامي وخلفي", round1(w - 5.0), 4, "قطاع مطبخ 2.5×2.5 سم"))
        cuttingSummary.add(CuttingPiece("قوائم شاسيه ارتفاع (الأركان)", round1(h), 4, "قطاع مطبخ رأسي"))
        cuttingSummary.add(CuttingPiece("قوائم عمق جانبية", round1(d - 5.0), 4, "ربط الشاسيه"))

        if (doorsCount > 0) {
            val doorW = round1((w - 1.5) / doorsCount)
            val doorH = round1(h - 3.0)
            cuttingSummary.add(CuttingPiece("ضلف مطبخ (عرض)", doorW, doorsCount * 2, "درف أمامية"))
            cuttingSummary.add(CuttingPiece("ضلف مطبخ (ارتفاع)", doorH, doorsCount * 2, "درف أمامية"))
        }

        if (drawersCount > 0) {
            val drawerW = round1(w - 6.0)
            cuttingSummary.add(CuttingPiece("علب أدراج (عرض)", drawerW, drawersCount * 2, "شاسيه الدرج"))
            cuttingSummary.add(CuttingPiece("علب أدراج (عمق)", round1(d - 5.0), drawersCount * 2, "شاسيه الدرج"))
        }

        var totalCm = 0.0
        for (c in cuttingSummary) {
            totalCm += c.lengthCm * c.count
        }
        val aluminumMeters = round2(totalCm / 100.0)
        val aluminumWeightKg = round2(aluminumMeters * 0.72 * (1.0 + settings.wastePercentage / 100.0))

        // حساب مساحة الفايبر / الكلادينج (جنبين + ظهر + قاع + سقف + أرفف + واجهة)
        val sidesArea = 2.0 * (d / 100.0) * (h / 100.0)
        val backAndFrontArea = 2.0 * (w / 100.0) * (h / 100.0)
        val topBottomShelvesArea = (2 + shelvesCount) * (w / 100.0) * (d / 100.0)
        val claddingAreaSqM = round2(sidesArea + backAndFrontArea + topBottomShelvesArea)

        val aluminumCostEgp = round1(aluminumWeightKg * settings.aluminumKgPriceEgp)
        val claddingCostEgp = round1(claddingAreaSqM * settings.kitchenCladdingSqMPriceEgp * claddingType.priceMultiplier)
        val accessoriesCostEgp = round1(
            settings.kitchenAccessorySetEgp +
                (doorsCount * 75.0) + // مفصلات باكم ومقابض
                (drawersCount * 180.0) // مجاري أدراج تليسكوب
        )
        val surfaceSqM = max((w / 100.0) * (h / 100.0), 0.8)
        val laborCostEgp = round1(surfaceSqM * settings.laborPerSqMEgp * 1.3)
        val totalPriceEgp = round1(aluminumCostEgp + claddingCostEgp + accessoriesCostEgp + laborCostEgp)

        return KitchenCalcResult(
            unitType = unitType,
            claddingType = claddingType,
            widthCm = w,
            heightCm = h,
            depthCm = d,
            doorsCount = doorsCount,
            drawersCount = drawersCount,
            shelvesCount = shelvesCount,
            aluminumMeters = aluminumMeters,
            aluminumWeightKg = aluminumWeightKg,
            claddingAreaSqM = claddingAreaSqM,
            cuttingSummary = cuttingSummary,
            aluminumCostEgp = aluminumCostEgp,
            claddingCostEgp = claddingCostEgp,
            accessoriesCostEgp = accessoriesCostEgp,
            laborCostEgp = laborCostEgp,
            totalPriceEgp = totalPriceEgp
        )
    }

    private fun round1(v: Double): Double = (v * 10.0).roundToInt() / 10.0
    private fun round2(v: Double): Double = (v * 100.0).roundToInt() / 100.0
}
