# ProGuard rules for Mahmoud Assistant
-keep class com.mahmoud.assistant.** { *; }
